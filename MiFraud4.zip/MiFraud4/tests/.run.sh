touch tests//.timeout
CMD="valgrind --leak-check=full /home/dgarlie213/Desktop/Home_Remoto/MP/UGRMPBase/CodeProjects/MiFraud4/build/MiFraud4  -K1 2 -K2 2 -o tests/output/predictionK12K26_princeton_3individuals.dts ../Datasets/dataP4/princeton_3individuals.dts ../Datasets/dataP4/princeton_3individuals.dts 1> tests//.out1 2>&1"
eval $CMD
rm tests//.timeout
