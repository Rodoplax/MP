touch tests//.timeout
CMD=" /home/usuario/Escritorio/MP/UGRMPBase/CodeProjects/MiFraud0/build/MiFraud0  < ../Datasets/dataP0/princeton_0locations.p0in 1> tests//.out7 2>&1"
eval $CMD
rm tests//.timeout
