/*
 * Metodología de la Programación
 * Curso 2025/2026
 */

/**
 * @file VectorInt.cpp
 * @author Silvia Acid Carrillo <acid@decsai.ugr.es>
 * @author Andrés Cano Utrera <acu@decsai.ugr.es>
 * @author Luis Castillo Vidal <L.Castillo@decsai.ugr.es>
 * 
 * Created on 30 de julio de 2025, 9:54
 */

#include "VectorInt.h"
#include <cmath>

using namespace std;

void VectorInt::_allocate(int size) {

    if(size < 0)
        throw out_of_range("Negative size in VectorInt::_allocate");

    _values = new int [size];
    _capacity = size;
}

void VectorInt::_resize(int size) {

    VectorInt temp(_capacity+size);
    temp._copy(*this);

    _capacity += size;
    delete[] _values;
    _values = temp._values;
    temp._values = nullptr;
}

void VectorInt::_copy(const VectorInt &other) {
    for (int i = 0; i < other._size; i++) {
        _values[i] = other._values[i];
    }
    _size = other._size;
}

void VectorInt::append(int value) {
    if (_size == _capacity)
        _resize(BLOCK_SIZE);
    _values[_size++] = value;
}

void VectorInt::assign(int value) {
    for (int i = 0; i < _size; i++)
        _values[i] = value;
}

int & VectorInt::at(int pos) {
    if (pos >= _size)
        throw std::out_of_range("void VectorInt::at(int pos) : Size of the array reached.");
    return _values[pos];
}

const int & VectorInt::at(int pos) const {
    if (pos >= _size)
        throw std::out_of_range("void VectorInt::at(int pos) : Size of the array reached.");
    return _values[pos];
}

void VectorInt::clear() {
    _size = 0;
}

int VectorInt::countIdenticalElements(const VectorInt &other) const {
    
    if (_size != other._size)
        throw std::invalid_argument(
            "The sizes of this and the provided object are different"
            );
    int count = 0;
    for (int i = 0; i<_size; i++)
        if (_values[i] == other._values[i])
            count++;
    return count;
}

double VectorInt::distance(const VectorInt &other) const {
    if (_size != other._size)
        throw std::invalid_argument(
            "The sizes of this and the provided object are different"
            );
    if (_size == 0 || other._size == 0)
        throw std::invalid_argument(
            "The size of one of the vectors is 0"
            );
    double sum = 0;
    for (int i = 0; i < _size; i++) {
        double diff = _values[i] - other._values[i];
        sum += diff * diff;
    }
    sum = sqrt(sum);
    return sum;
}

int VectorInt::getCapacity() const {
    return _capacity;
}

int VectorInt::getSize() const {
    return _size;
}

std::string VectorInt::toString() const {
    std::string output;
    output+= std::to_string(_size);
    output+= '\n';
    for (int i=0; i<_size-1; i++) {
        output+= to_string(_values[i]);
        output+= ' ';
    }

    if (_size > 0) {
        output+= to_string(_values[_size-1]);
        output+= '\n';
    }
    return output;
}

VectorInt::VectorInt(int size) {

    if (size < 0)
        throw out_of_range(" size must be > 0");
    
    _allocate(size);
    _size = size;
    assign();
}

VectorInt::VectorInt(const VectorInt &orig) {
    _allocate(orig._size);
    _copy(orig);
}

VectorInt &VectorInt::operator=(const VectorInt &orig) {
    if (&orig != this) {
        delete [] _values;
        _size = 0;
        _capacity = 0;
        _allocate(orig._size);
        _copy(orig);
    }
    return *this;
}

VectorInt::~VectorInt() {
    delete [] _values;
}

const int& VectorInt::operator[](int index) const{
    return _values[index];
}

int& VectorInt::operator[](int index){
    return _values[index];
}

VectorInt& VectorInt::operator+=(int value){
    append(value);
    return *this;
}

std::ostream& operator<<(std::ostream& os, const VectorInt& vector){
    os << vector.toString();
    return os;
}

std::istream& operator>>(std::istream& is, VectorInt& vector){

    int n = 0;
    is >> n;

    vector.clear();
    
    if(n < 0)
        throw out_of_range("Number of elements read cannot be negative");

    for(int i = 0; i < n; ++i){
        int temp;
        is >> temp;
        vector.append(temp);
    }

    return is;
}