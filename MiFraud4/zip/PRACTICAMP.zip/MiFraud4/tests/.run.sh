touch tests//.timeout
CMD="valgrind --leak-check=full /home/usuario/Escritorio/MP/UGRMPBase/CodeProjects/MiFraud4/build/MiFraud4  -K1 10 -K2 7 ../Datasets/princeton_training.dts ../Datasets/princeton_test.dts 1> tests//.out16 2>&1"
eval $CMD
rm tests//.timeout
