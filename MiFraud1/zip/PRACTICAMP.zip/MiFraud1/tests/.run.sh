touch tests//.timeout
CMD=" /home/usuario/Escritorio/UGRMPBase/CodeProjects/MiFraud1/build/MiFraud1  < ../Datasets/dataP1/princeton.p1in 1> tests//.out8 2>&1"
eval $CMD
rm tests//.timeout
